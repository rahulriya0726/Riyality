<!doctype html>
<html lang="zxx">

<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

	<link rel="stylesheet" href="assets/css/animate.min.css">

	<link rel="stylesheet" href="assets/css/boxicons.min.css">

	<link rel="stylesheet" href="assets/css/meanmenu.css">

	<link rel="stylesheet" href="assets/css/nice-select.min.css">

	<link rel="stylesheet" href="assets/css/style.css">

	<link rel="stylesheet" href="assets/css/responsive.css">

	<title>Java Under Tree</title>

	<link rel="icon" type="image/png" href="assets/img/favicon.png">
</head>
<body>

	<!-- <div class="preloader">
		<div class="d-table">
			<div class="d-table-cell">
				<div class="pre-img">
					<img src="assets/img/logo.jpg" alt="Logo">
				</div>
				<div class="spinner">
					<div class="circle1"></div>
					<div class="circle2"></div>
					<div class="circle3"></div>
				</div>
			</div>
		</div>
	</div> -->


	<div class="navbar-area">

		<div class="mobile-nav">
			<a href="index.html" class="logo">
				<img src="assets/img/logo.png" alt="Logo">
			</a>
		</div>

		<div class="top-nav main-nav">
			<div class="container">
				<nav class="navbar navbar-expand-md navbar-light ">
					<a class="navbar-brand" href="index.html">
						<img src="assets/img/logo.png" alt="Logo" height="85px">
					</a>
					<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
						<ul class="navbar-nav m-auto">
							<li class="nav-item">
								<a href="index.php" class="nav-link">
									Home
								</a>
							</li>
							<li class="nav-item">
								<a href="aboutUs.php" class="nav-link">
									About Us
								</a>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link">
									Our Cources
									<i class='bx bx-plus'></i>
								</a>
								<ul class="dropdown-menu">
									<li class="nav-item">
										<a href="core-java.php" class="nav-link">
											Core Java
										</a>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link">
											JDBC & Servlet
										</a>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link">
											Spring, Spring Boot
										</a>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link">
											Webservices
										</a>
									</li>
									<li class="nav-item">
										<a href="faq.html" class="nav-link">
											HTML, CSS, Bootstrap
										</a>
									</li>
									<li class="nav-item">
										<a href="faq.html" class="nav-link">
											JavaScript & jQuery
										</a>
									</li>
									<li class="nav-item">
										<a href="designer.html" class="nav-link">
											React Js
										</a>
									</li>
									<li class="nav-item">
										<a href="testimonials.html" class="nav-link">
											C & C++ Programming
										</a> 
									</li>
									
									
								</ul>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link">
									Corporate Training
								</a>
							</li>
							<li class="nav-item">
								<a href="testimonials.php" class="nav-link">
									Our Student Say's
								</a>
							</li>
							<li class="nav-item">
								<a href="contactUs.php" class="nav-link">
									Contact Us
								</a>
							</li>
						</ul>

					</div>
				</nav>
			</div>
		</div>
	</div>


	<div class="sidebar-modal">
		<div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">
								<i class="bx bx-x"></i>
							</span>
						</button>
						<h2 class="modal-title" id="myModalLabel2">
							<a href="index.html">
								<img src="assets/img/logo.png" alt="Logo">
							</a>
						</h2>
					</div>
					<div class="modal-body">
						<div class="sidebar-modal-widget">
							<h3 class="title">About Us</h3>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, asperiores doloribus eum laboriosam praesentium delectus unde magni aut perspiciatis cumque deserunt dolore voluptate, autem pariatur.</p>
						</div>
						<div class="sidebar-modal-widget">
							<h3 class="title">Blog Links</h3>
							<div class="modal-widget-blog">
								<ul>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/1.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/2.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/3.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/4.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/5.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/6.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/7.jpg" alt="Blog Images">
										</a>
									</li>
									<li>
										<a href="blog-details.html">
											<img src="assets/img/blog/8.jpg" alt="Blog Images">
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="sidebar-modal-widget">
							<h3 class="title">Contact Info</h3>
							<ul class="contact-info">
								<li>
									<i class='bx bx-map'></i>
									Address
									<span>28/A Street, New York, USA</span>
								</li>
								<li>
									<i class='bx bxs-paper-plane'></i>
									Email
									<span><a href="https://templates.hibootstrap.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="f6939b979f9ab6869f8e9f85d895999b">[email&#160;protected]</a></span>
								</li>
								<li>
									<i class='bx bxs-phone-call'></i>
									Phone
									<span>+1 1234 56 7891, +1 1234 76 6871</span>
								</li>
							</ul>
						</div>
						<div class="sidebar-modal-widget">
							<h3 class="title">Connect With Us</h3>
							<ul class="social-list">
								<li>
									<a href="#">
										<i class="bx bxl-facebook"></i>
									</a>
								</li>
								<li>
									<a href="#">
										<i class="bx bxl-twitter"></i>
									</a>
								</li>
								<li>
									<a href="#">
										<i class='bx bxl-youtube'></i>
									</a>
								</li>
								<li>
									<a href="#">
										<i class='bx bxl-instagram'></i>
									</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>