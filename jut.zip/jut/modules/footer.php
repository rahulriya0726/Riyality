<footer class="footer-area">
		<div class="container">
			<div class="footer-contact">
				<div class="row">
					<div class="col-lg-4 col-md-4">
						<div class="footer-card">
							<i class='bx bx-time'></i>
							<h3>Mon - Sun : 10:00 AM - 11:00 PM</h3>
						</div>
					</div>
					<div class="col-lg-4 col-md-4">
						<div class="footer-card">
							<i class='bx bxs-map'></i>
							<h3>All Over World Online Classes</h3>
						</div>
					</div>
					<div class="col-lg-4 col-md-4">
						<div class="footer-card">
							<i class='bx bxs-phone-call'></i>
							<h3 class="media-tel">
								<a href="tel:+19876543210">+91 800 800 8888</a>
							</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-top-list pb-70">
				<div class="row">
					<div class="col-lg-4 col-md-4">
						<div class="footer-list">
							<h3>Courses</h3>
							<ul>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="#">Complete Java</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="#">Web Designing</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="#">JavaScript and jQuery</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="#">React Js</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-3">
						<div class="footer-list">
							<h3>Quick Links</h3>
							<ul>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="index.php">Home</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="aboutUs.php">About Us</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="testimonials.php">Testimonials</a>
								</li>
								<li>
									<i class='bx bxs-chevron-right'></i>
									<a href="contactUs.php">Contact Us</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-lg-5 col-md-5">
						<div class="footer-side-list">
							<h3>Contact Us</h3>
							<ul>
								<li>
									<i class='bx bxs-phone'></i>
									<a href="tel:+11234567891">+91 999 999 9999</a>
								</li>
								<li>
									<i class='bx bxs-phone'></i>
									<a href="tel:+19876543210">+91 999 999 9999</a>
								</li>
								<li>
									<i class='bx bxs-map'></i>
									All Over World Online Classes
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-md-2">
						<div class="footer-logo">
							<img src="assets/img/logo.jpg" alt="Footer Logo">
						</div>
					</div>
					<div class="col-lg-10 col-md-10">
						<div class="bottom-text">
							<p>
								Copyright ©2022 Java Under Tree. All Rights Reserved by
								<a href="index.php" target="_blank">Java Under Tree</a>
							</p>
							<ul class="social-bottom">
								<li>
									<a href="#"><i class='bx bxl-facebook'></i></a>
								</li>
								<li>
									<a href="#"><i class='bx bxl-twitter'></i></a>
								</li>
								<li>
									<a href="#"><i class='bx bxl-instagram'></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>


	<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.5.1.slim.min.js"></script>

	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<script src="assets/js/owl.carousel.min.js"></script>

	<script src="assets/js/meanmenu.js"></script>

	<script src="assets/js/wow.min.js"></script>

	<script src="assets/js/jquery.nice-select.min.js"></script>

	<script src="assets/js/jquery.ajaxchimp.min.js"></script>

	<script src="assets/js/form-validator.min.js"></script>

	<script src="assets/js/contact-form-script.js"></script>

	<script src="assets/js/custom.js"></script>
</body>

</html>