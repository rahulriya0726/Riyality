

<?php
include 'modules/header.php';
?>

<div class="inner-banner inner-bg1">
	<div class="container">
		<div class="inner-title">
			<h3>Core Java</h3>
			<ul>
				<li>
					<a href="index.php">Home</a>
				</li>
				<li>
					<i class='bx bxs-chevrons-right'></i>
				</li>
				<li>Core Java</li>
			</ul>
		</div>
	</div>
</div>

<div class="blog-dtls pt-100 ptb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-4">
				<div class="widget-area">

					<section class="widget widget_categories">
						<h3 class="widget-title">Our Courses</h3>
						<div class="post-wrap">
							<ul>
								<li>
									<a href="core-java.php"><b>C & C++ Programming</b></a>
								</li>
								<li>
									<a href="core-java.php" class="active-color"><b>Core Java</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>JDBC & Servlet (Advance Java)</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>Spring Frameword</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>Spring Boot</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>RestFul Webservices</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>Micro Service</b></a>
								</li>
								
							</ul>
						</div>
					</section>

					<section class="widget widget_categories">
						<h3 class="widget-title">Tranding Courses</h3>
						<div class="post-wrap">
							<ul>
								<li>
									<a href="core-java.php"><b>React Js</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>Angular Js</b></a>
								</li>
							</ul>
						</div>
					</section>

					<section class="widget widget_categories">
						<h3 class="widget-title">Web Designing</h3>
						<div class="post-wrap">
							<ul>
								<li>
									<a href="core-java.php"><b>HTML & CSS</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>Bootstrap</b></a>
								</li>
								<li>
									<a href="core-java.php"><b>JavaScript & jQuery</b></a>
								</li>
							</ul>
						</div>
					</section>
					
				</div>
			</div>
			<div class="col-lg-8">
				<div class="blog-dtls-content">
					<div class="blog-text">
						<h2>What is Core Java ?</h2>
						
						<blockquote class="boxicon-quote">
							<p>
								The word Core describes the basic concept of something, and here, the phrase 'Core Java' defines the basic Java that covers the basic concept of Java programming language.
							</p>
						</blockquote>

<div class="row blog-gallery">
						<div class="blog-gallery-item">
							<img src="assets/img/courses/core-java1.jpg" alt="core-java Images" height="175px" width="100%">
						</div>
						<div class="blog-gallery-item">
							<img src="assets/img/courses/core-java2.jpg" alt="core-java Images"height="175px" width="100%">
						</div>
						<div class="blog-gallery-item">
							<img src="assets/img/courses/core-java3.jpg" alt="core-java Images"height="175px" width="100%">
						</div>
					</div>
					<h3>We Cover All Topics Like...</h3>
					<p>
						1. Java Fundamentals
					</p>
					<p>
						2. OOPs Concepts
					</p>
					<p>
						3. Overloading & Overriding
					</p>
					<p>
						4. Inheritance with Interface and Abstract Class
					</p>
					<p>
						5. Exception Handling
					</p>
					<p>
						6. Java.lang Packages
					</p>
					<p>
						7. Java Vitual Machine (JVM)
					</p>
					<p>
						8. Collections
					</p>
					<p>
						9. Multithreading
				
					</p>
						
						<p>
							We all are aware that Java is one of the well-known and widely used programming languages, and to begin with it, the beginner has to start the journey with Core Java and then towards the Advance Java. The Java programming language is a general-purpose programming language that is based on the OOPs concept. The ocean of Java is too deep to learn, i.e., as much you learn more, you will know its depth. Java is a platform-independent and robust programming language. The principle followed by Java is WORA that says Write Once, Run Anywhere. The programming language is quite simple and easy to understand. But one should know that Core Java is not different from Java. Java is complete in itself, but for the beginners, it is natural that the beginner must begin with the core concepts of Java. In actual, Java has different editions, where Core Java is one of the parts of an edition.
						</p>
						<p>
							The Java SE is a computing-based platform and used for developing desktop or Window based applications. Thus, core Java is the part of Java SE where the developers develop desktop-based applications by using the basic concepts of Java where JDK (Java Development Kit) is a quite familiar Java SE implementation.
						</p>
						<p>
							Also known as Java 2 Platform or J2EE. It is the enterprise platform where a developer develops applications on the servers, i.e., the enterprise development. This edition is used for web development.
						</p>
					</div>
					<!-- <div class="blog-dtls-img">
						<img src="assets/img/blog/blog-dtls.jpg" alt="Blog Images">
					</div> -->

					
					
					
					
				</div>
			</div>
		</div>
	</div>
</div>


<?php
include 'modules/footer.php';
?>