
<?php
    include 'modules/header.php';
?>

<div class="inner-banner inner-bg1">
	<div class="container">
		<div class="inner-title">
			<h3>Our Student Say's About Us</h3>
			<ul>
				<li>
					<a href="index.php">Home</a>
				</li>
				<li>
					<i class='bx bxs-chevrons-right'></i>
				</li>
				<li>Our Student Say's About Us</li>
			</ul>
		</div>
	</div>
</div>	

<div class="client-area pt-150 pb-70">
	<div class="container">
		<div class="section-title text-center">
			<h2>Student's Says About Us</h2>
			<p>
				Success is no accident. It is hard work, perseverance, learning, studying, sacrifice and most of all, love of what you are doing or learning to do.
			</p>
		</div>
		<div class="row pt-45">

			<div class="col-lg-6">
				<div class="client-card">
					<img src="assets/img/testimonial/4.jpg" alt="Images">
					<h3>Dilip Patil</h3>
					<p>“I joined this institute to take training for Java. My all over experience is very good. The knowledge given by the sir is very helpful to me & during training they solve thought related the topic. Thank you.”
					</p>
				</div>
			</div>

			<div class="col-lg-6">
				<div class="client-card">
					<img src="assets/img/testimonial/4.jpg" alt="Images">
					<h3>Aditya Patil</h3>
					<p>“Provided in depth knowledge about the topics. Shown most of the topics practically which help in visualizing the topic.”
					</p>
					<br>
					<br>
				</div>
			</div>

			<div class="col-lg-6">
				<div class="client-card">
					<img src="assets/img/testimonial/4.jpg" alt="Images">
					<h3>Pravin Chavan</h3>
					<p>“Training was excellent with good interaction. Knowledge sharing is good. Recording facility is excellent for revising. Course was practically and informative. The course helped to build confidence, Valuable experiences and learning.”
					</p>
				</div>
			</div>

			<div class="col-lg-6">
				<div class="client-card">
					<img src="assets/img/testimonial/4.jpg" alt="Images">
					<h3>Rohit Kalebag</h3>
					<p>“Overall a very informative training session. Course content got well covered and also demonstrated the concept very well. Thanks for such an informative and concept-clearing training session. Thank you.”
					</p>
				</div>
			</div>

			<div class="col-lg-12">
				<div class="pagination-area">
					<nav aria-label="Page navigation example text-center">
						<ul class="pagination">
							<li class="page-item">
								<a class="page-link page-links" href="#">
									<i class='bx bx-chevrons-left'></i>
								</a>
							</li>
							<li class="page-item current">
								<a class="page-link" href="#">1</a>
							</li>
							<li class="page-item">
								<a class="page-link" href="#">2</a>
							</li>
							<li class="page-item">
								<a class="page-link" href="#">3</a>
							</li>
							<li class="page-item">
								<a class="page-link" href="#">
									<i class='bx bx-chevrons-right'></i>
								</a>
							</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
    include 'modules/footer.php';
?>