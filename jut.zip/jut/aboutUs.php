
<?php
    include 'modules/header.php';
?>

<div class="inner-banner inner-bg1">
	<div class="container">
		<div class="inner-title">
			<h3>About Us</h3>
			<ul>
				<li>
					<a href="index.php">Home</a>
				</li>
				<li>
					<i class='bx bxs-chevrons-right'></i>
				</li>
				<li>About Us</li>
			</ul>
		</div>
	</div>
</div>


<div class="about-area pb-70">
	<div class="container-fluid">
		<div class="row align-items-center">
			<div class="col-lg-5">
				<div class="about-img">
					<img src="assets/img/courses/about1.jpg" alt="About Images">
				</div>
			</div>
			<div class="col-lg-7">
				<div class="about-content" style="margin-top: 120px">
					<span>About Us</span>
					<h2>We Are Leading Our Training Institute from last 6+ Years</h2>
					<p>
						What indication best sick be project proposal in attempt, train of
						the showed some a forth. That homeless, won't many of goals thoughts
						volumes felt with of as he this its tend broad. Well, were make come
						when from would area page.
					</p>
					<p>
						What indication best sick be project proposal in attempt, train of the
						showed some a forth. That homeless, won't many of goals thoughts volumes
						felt with of as he this its tend broad. Well, were make come when from would
						area page puzzles hell in is through on the in more rent mountains.
					</p>
				</div>
			</div>
		</div>
	</div>
</div>


	<section class="choose-area ptb-100 pb-70">
		<div class="container">
			<div class="section-title text-center">
				<span>Why Choose Us</span>
				<h2>Why Java Under Tree</h2>
				<p>
					What indication best sick be project proposal in attempt, train of the showed
					some a forth. That homeless, won't many of goals thoughts volumes felt.
				</p>
			</div>
			<div class="row pt-45">
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-box'></i>
						<h3>Trusted Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxs-coin-stack'></i>
						<h3>15 day's Free Demo</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxs-truck'></i>
						<h3>100% Knowlegde Surety</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxl-creative-commons'></i>
						<h3>Quality Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-brush'></i>
						<h3>Proper Training Note </h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-paint'></i>
						<h3>Regular Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-like'></i>
						<h3>Satisfaction Revisions</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-money'></i>
						<h3>Money Back Guarantee</h3>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php
    include 'modules/footer.php';
?>