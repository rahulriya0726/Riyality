<?php
    include 'modules/header.php';
?>

<div class="main-banner pt-100">
	<div class="container-fluid">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="banner-content">
					<h1>We Are Create Full Stack Java Developer</h1>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiu
						smod tempor incididunt ut labore et dolore magna aliqua. Quis
						ipsum suspendisse ultrices gravida.
					</p>
					<div class="banner-btn">
						<a href="aboutUs.php" class="default-btn">Know More</a>
						<a href="#" class="default-btn active">Our Courses</a>
					</div>
				</div>
			</div>
			<div class="col-lg-6 pe-0">
				<div class="banner-img">
					<img src="assets/img/courses/about.jpg" alt="Banner Images">
				</div>
			</div>
		</div>
	</div>
</div>

<section class="service-area service-bg pb-70" style="padding-top: 50px">
	<div class="container">
			<div class="section-title text-center">
				<span>Courses</span>
				<h2>We Provide Courses</h2>
				<p>
					What indication best sick be project proposal in attempt, train of the showed
					some a forth. That homeless, won't many of goals thoughts volumes felt.
				</p>
			</div>
			<div class="col-lg-12 col-md-12">
				<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
			</div>
	</div>
</section>


	<section class="service-area service-bg pb-70" style="padding-top: 50px">
		<div class="container">
			<div class="section-title text-center">
				<span>Courses</span>
				<h2>We Provide Courses</h2>
				<p>
					What indication best sick be project proposal in attempt, train of the showed
					some a forth. That homeless, won't many of goals thoughts volumes felt.
				</p>
			</div>
			<div class="row pt-45">

				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="core-java.php">
							<img src="assets/img/courses/core-java.jpg" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="core-java.php"><h3>Core Java</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="core-java.php" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="services.html">
							<img src="assets/img/courses/java1.jpg" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="#"><h3>Advance Java</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="#" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="services.html">
							<img src="assets/img/courses/html.jpg" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="#"><h3>HTML, CSS, Bootstrap</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="#" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="services.html">
							<img src="assets/img/courses/javascript1.jpg" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="#"><h3>JavaScript & jQuery</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="#" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="services.html">
							<img src="assets/img/courses/reactjs.png" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="#"><h3>React Js</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="#" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
				<div class="col-lg-4 col-md-6">
					<div class="service-card">
						<a href="services.html">
							<img src="assets/img/courses/angularjs.jpg" alt="Course Images" height="200px" width="100%">
						</a>
						<div class="service-content">
							<a href="#"><h3>Angular Js</h3></a>
							<p>Lorem ipsum dolor sit amet, consect is etur adipiscing elit, sed do eiusmo gd tempor incididunt ut labore.</p>
							<a href="#" class="more-btn">
							  <i class='bx bx-right-arrow-alt'></i>
							</a>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>

	<div class="testimonial-area-two testimonial-bottom pb-90 pt-45">
		<div class="container">
			<div class="section-title text-center">
				<h2 class="text-white">Student's Says About Us</h2>
			</div>
			<div class="testimonial-slider-two owl-carousel owl-theme pt-45">

				<div class="testimonial-card">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<div class="testimonial-card-content">
								<h3>Dilip Patil</h3>
								<p>
									“I joined this institute to take training for Java. My all over experience is very good. The knowledge given by the sir is very helpful to me & during training they solve thought related the topic. Thank you.”
								</p>
							</div>
						</div>
						<div class="col-lg-5">
							<div class="testimonial-img-2">
								<img src="assets/img/testimonial/1.png" alt="Testimonial Images">
							</div>
						</div>
					</div>
				</div>

				<div class="testimonial-card">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<div class="testimonial-card-content">
								<h3>Rohit Kalebag</h3>
								<p>
									“Overall a very informative training session. Course content got well covered and also demonstrated the concept very well. Thanks for such an informative and concept-clearing training session. Thank you.”
								</p>
							</div>
						</div>
						<div class="col-lg-5">
							<div class="testimonial-img-2">
								<img src="assets/img/testimonial/1.png" alt="Testimonial Images">
							</div>
						</div>
					</div>
				</div>

				

			</div>
		</div>
		<div class="testimonial-icon">
			<i class='bx bxs-quote-alt-right'></i>
		</div>
	</div>


	<section class="choose-area ptb-100 pb-70">
		<div class="container">
			<div class="section-title text-center">
				<span>Why Choose Us</span>
				<h2>Why Java Under Tree</h2>
				<p>
					What indication best sick be project proposal in attempt, train of the showed
					some a forth. That homeless, won't many of goals thoughts volumes felt.
				</p>
			</div>
			<div class="row pt-45">
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-box'></i>
						<h3>Trusted Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxs-coin-stack'></i>
						<h3>15 day's Free Demo</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxs-truck'></i>
						<h3>100% Knowlegde Surety</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bxl-creative-commons'></i>
						<h3>Quality Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-brush'></i>
						<h3>Proper Training Note </h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-paint'></i>
						<h3>Regular Training</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-like'></i>
						<h3>Satisfaction Revisions</h3>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="choose-card">
						<i class='bx bx-money'></i>
						<h3>Money Back Guarantee</h3>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php
    include 'modules/footer.php';
?>